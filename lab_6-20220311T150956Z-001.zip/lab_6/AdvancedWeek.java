public class AdvancedWeek {
    // Initializing variables
    private String day_1 = "Monday";
    private int day_1_index = 1;
    /**
     * Continue filling variables
     */

    // printing out the days
    public void printDays() {
        System.out.println( /* Insert string to be printed out */ );
    }
}